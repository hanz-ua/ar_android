package com.bvblogic.arandroid.media.core;

/**
 * Created by hanz on 29.03.2018.
 */

public interface MediaListener {
    void onStart();

    void onFinish();
}
